create procedure portal_host_list(IN pageIndex int, IN pageSize int, OUT pageCount int, IN strWhere varchar(1000))
  begin
	declare startIndex int;
	declare temp_str varchar(1000);
	set startIndex=(pageIndex-1)*pageSize;
	if strWhere='' or strWhere is NULL then
		set strWhere='1=1';
	end if;
	set @sql_str=concat('select count(1) into @cnt from portal_host where  ',strWhere);
  PREPARE stmt FROM @sql_str;
	EXECUTE stmt;
	deallocate prepare stmt;
	SET pageCount = @cnt;
	if pageSize=0 then
		set temp_str=concat('select id,mode_id,host,path,name,class,subclass_1,subclass_2,subclass_3,subclass_4,subclass_5,update_date from portal_host where  ',strWhere);
	else
		set temp_str=concat('select id,mode_id,host,path,name,class,subclass_1,subclass_2,subclass_3,subclass_4,subclass_5,update_date from portal_host where  ',strWhere,' LIMIT ',startIndex,',',pageSize);
	end if;
	set @sql_str=temp_str;
	PREPARE stmt from @sql_str;
  EXECUTE stmt; 
	deallocate prepare stmt;
end;

