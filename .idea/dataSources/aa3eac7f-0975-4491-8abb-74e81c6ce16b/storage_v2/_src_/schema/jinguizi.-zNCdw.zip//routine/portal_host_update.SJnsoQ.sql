create procedure portal_host_update(IN strSet varchar(500), IN strWhere varchar(500))
  begin
	set @sql_str=concat('update portal_host set ',strSet,' where ',strWhere);
  PREPARE stmt FROM @sql_str;
	EXECUTE stmt;
	deallocate prepare stmt;
end;

