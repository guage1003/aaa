create procedure check_login(IN userName varchar(255), IN userPassword varchar(255))
  begin
	declare i_count int;
	declare i_id int;
	select count(1) into i_count from portal_user where user_name=userName;
	if i_count>0 then
		select count(1) into i_count from portal_user where user_name=userName and user_password=userPassword;
		if i_count>0 then
			select user_id into i_id from portal_user where user_name=userName and user_password=userPassword;
		else
			set i_id=-2;
		end if;
	else
		set i_id=-1;
	end if;
	select i_id;
end;

